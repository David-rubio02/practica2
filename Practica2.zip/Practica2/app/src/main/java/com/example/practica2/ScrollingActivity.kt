package com.example.practica2

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.practica2.clases.CentroComercial
import com.example.practica2.clases.Tienda
import com.example.practica2.databinding.ActivityScrollingBinding

class ScrollingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScrollingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityScrollingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var i = Intent(this, TiendasActivity::class.java)

        loadImageBonaire()

        //Tiendas
        val zara = Tienda("Zara","Tienda de ropa, pertenece a Inditex")
        val game = Tienda("Game","Tienda de videojuegos")
        val snipes = Tienda("Snipes","Tienda de ropa para jovenes")
        val mcdonals = Tienda("McDonal's","Tienda comida rapida")
        val alcampo = Tienda("Alcampo","supermercado, vende de todo")

        //Listas
        val listaBonaire = mutableListOf(zara, alcampo)

        //Centros comerciales
        val bonaire = CentroComercial(1,"Bonaire","Centro comercial Bonaire, Autovía del Este, Km. 345, 46960, Valencia",listaBonaire.size,listaBonaire)

        binding.content.tvNombreBonaire.text = bonaire.nombre+ "\n" +bonaire.direccion
        binding.content.tvTiendasBonaire.text = "${bonaire.nTiendas} Tiendas"

        binding.content.cvBonaire.setOnClickListener() {
            i.putExtra("idcc", bonaire.id.toString())
            startActivity(i)
        }
    }

    private fun loadImageBonaire(url: String = "https://www.guiagps.com/wp-content/uploads/2020/06/tiendas-moda.jpg") {
        Glide.with(this)
            .load(url)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .centerCrop()
            .into(binding.content.imgBonaire)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_scrolling, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
}