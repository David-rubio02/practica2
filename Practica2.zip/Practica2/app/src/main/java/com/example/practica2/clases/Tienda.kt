package com.example.practica2.clases

data class Tienda(val nombre: String, val descripcion: String){

}
